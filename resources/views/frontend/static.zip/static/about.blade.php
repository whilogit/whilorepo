@extends('frontend.layouts.master')

@section('content')

<!-- MOBILE MENU - Option 2 -->
<section id="navMobile" class="aside-menu left">
    <form class="form-horizontal form-search">
        <div class="input-group">
            <input type="search" class="form-control" placeholder="Search...">
            <span class="input-group-btn">
                <button id="btnHideMobileNav" class="btn btn-close" type="button" title="Hide sidebar"><i class="fa fa-times"></i></button>
            </span>
        </div>
    </form>
    <div id="dl-menu" class="dl-menuwrapper">
        <ul class="dl-menu"></ul>
    </div>
</section> 

<!-- MAIN WRAPPER -->
<div class="body-wrap">
   <!-- HEADER -->
        <div id="divHeaderWrapper" class="navbar-fixed-top bounceInDown animated">
            <header class="header-standard-2">     
    <!-- MAIN NAV -->
    <div class="navbar navbar-wp navbar-arrow mega-nav" role="navigation">
        <div class="container">
            <div class="navbar-header">
              
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <i class="fa fa-bars icon-custom"></i>
                </button>

                <a class="navbar-brand" href="index.html" title="Whilo | Job Portal and one stop solution for your career">
                    <img src="images/logo.png" alt="Whilo | Job Portal and one stop solution for your career">
                </a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-left">
                   
                    <li class=" mega-dropdown-fluid"><a href="#">TALENTS</a></li>
					<li class=" mega-dropdown-fluid"><a href="#">COMPANIES</a></li>
					<li class=" mega-dropdown-fluid"><a href="#">CONSULTANTS</a></li>
					<li class=" mega-dropdown-fluid"><a href="#">COURSES</a></li>
                                        <li class=" mega-dropdown-fluid"><a href="#">SERVICES</a></li>
		        </ul>
				<ul class="nav navbar-nav navbar-right">
                   
                    <li class=" mega-dropdown-fluid"><a href="#">LOGIN</a></li>
					<li class=" mega-dropdown-fluid"><a href="#">FOR Employers</a></li>
		        </ul>
               
            </div><!--/.nav-collapse -->
        </div>
    </div>
</header>        </div>

        <!-- Optional header components (ex: slider) -->
  <!-- MAIN CONTENT -->
        <div class="pg-opt" style="margin-top:5%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>About us</h2>
                </div>
                <div class="col-md-6">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">About us</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>



   <section class="slice bg-base" style="background-size: cover;background-image: url(images/aboutbg.jpg)">
           <div class="wp-section">
            <div class="container">
                <div class="row"><h4 class="col-md-12">About Us</h4>
                    <div class="col-md-6"><p>
                        <b>We’re on a mission to disrupt an entire industry.</b><br/>
Our simple goal is to make hiring easy. To help businesses get the talent they need to succeed. And to help people find a job they love.<br/>
Everyone is incredibly frustrated by how hard it is to find amazing talent. We share that frustration.<br/>
Recruiting is a fragmented, opaque process undermined by outdated technology that turns off candidates and hiring managers.<br/>
Now, imagine a world where it’s easy to find great candidates, it’s easy for people to show interest in jobs, it’s easy for hiring teams to collaborate, and your recruiting vendors are just a click away.<br/>
 
We imagined it. And then we delivered it. <br/>
<b>Whilo India</b><br/>
<b>Your Recruiting Success Platform</b><br/>
  <img src="images/signature.jpg"/><br/>
<b>DR Prajwal Bhat</b><br/>
Founder, CEO & Board Member
</p>
                    </div>
                    <div class="col-md-6">
                         <p>Whilo is India’s juvenile career site for job seekers and a leader in HR technology solutions for employers. Since 2012, we have helped connect employers and candidates through exclusive partnerships and community sites, social networking, and mobile optimization. <br/>
We find India’s real grafters – the people working tirelessly behind the scenes to keep our economy thriving. From the teachers educating our kids to the drivers delivering our parcels. The people running our hospital wards to the engineers patching up our roads. <br/>
The objective is to fundamentally changing the way in which job seekers look for jobs and the way employers scout for talent – That’s the only reason for us to be with you. <br/>
To help Indian employers attract top talent, as well as engage and retain employees, Whilo offers a wide range of HR technology solutions and expertise – including in-house recruiting specialists, flexible job posting packages, niche networks, and video interviewing – for business of all sizes.
</p>
                    </div>

<div class="col-md-12"><h4  style="font-style:italic;"><b>Technology powers companies. Professionals power technology. Whilo quickly delivers the opportunities, insights and connections technology professionals and employers need to move forward.</b></h4></div>
   <div class="col-md-6">
                         <p><b>Who are we?</b><br/>
Whilo is the work of a small team of committed individuals who want to redefine the job search experience for Indians. <br/>
<b>What we stand for?</b>
People are your most valuable assets: hiring is one of the most important decisions you make. We have the experience, knowledge and scale to provide you with the managerial, technical or practical expertise to help your organisation flourish.<br/>
<b>Who’s funding Whilo?</b><br/>
Whilo is boot strapped and has received no external funding so far. <br/>
<b>Our Philosophy</b><br/>
We want to keep things simple and easy to use. We believe that if there’s a job advertised out there, it should be easily accessible to you. You should not be denied the opportunity to find that perfect job, simply because you didn’t know it even existed! <br/>

</p>
                    </div>  
<div class="col-md-6"><p>
                        We are organizing the world’s talent by providing specialized insights and relevant connections tailored to specific professions and industries. Today, we serve:<br/>
<ul class="list-check"><li><i class="fa fa-caret-right" aria-hidden="true"></i> Technology</li>
<li><i class="fa fa-caret-right" aria-hidden="true"></i> Security-Clearance</li>
<li><i class="fa fa-caret-right" aria-hidden="true"></i> Financial Services</li>
<li><i class="fa fa-caret-right" aria-hidden="true"></i> Energy</li>
<li><i class="fa fa-caret-right" aria-hidden="true"></i> Healthcare</li>
<li><i class="fa fa-caret-right" aria-hidden="true"></i> Hospitality</li></ul>

 

</p>
                    </div>                 

<div class="col-md-12">
<p>
<b>Whilo in Training Services</b><br/>
<b>Whilo Training provides management and personal skills development, focused on developing better skills for better business®.</b><br/>
Whilo Training plugs in the economical gap by providing industry access and better employ-ability to urban and rural youth. <br/>
Our team’s well researched-transformative methodology, tried and tested over the years, successfully improves the reflective thinking of urban and rural youth. <br/>
<b>Corporate Leadership Program, </b>the instructor led training program integrated with modern teaching pedagogy makes the learning more exciting and instrumental. Our transformative training program has built generic competency in the students that is required to excel in the workforce and sustain growth with better livelihood.

</p>
</div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="row">
			 <div class="col-md-3">
                    <div class="col">
                      <h4>&nbsp; </h4>
                        <p class="no-margin">
                     Whilo is a specialist provider of permanent, contract, temporary and outsourced recruitment solutions, IT and HR consulting. Assisting jobseekers and employers since 2012, Whilo's expertise spans across India, Europe, and the Middle East.
                        <br><br>
                        <a href="#" class="btn btn-block btn-base btn-icon fa-check"><span>Contact Us</span></a>
                        </p>
                    </div>
                </div>
				<div class="col-md-2">
                    <div class="col">
                       <h4>Company</h4>
                       <ul>
                            <li>About us</li>
                            <li>Terms of Service</li>
                            <li>Terms of Use</li>
                            <li>Privacy</li>
                            <li>Testimonials</li>
							<li>Opt In - Opt Out</li>
                            <li>Careers</li>
                        </ul>
                     </div>
                </div>
				<div class="col-md-2">
                    <div class="col">
                       <h4>Services</h4>
                       <ul>
                            <li>Payroll</li>
                            <li>Train, Hire & Deploy</li>
                            <li>Dedicated Recruitment Assistance</li>
                            <li>Pricing</li>
                            <li>Campus Drives</li>
							<li>Employee Verification</li>
                            <li>Database Management</li>
                        </ul>
                     </div>
                </div>
				<div class="col-md-2">
                    <div class="col">
                       <h4>Courses</h4>
                       <ul>
                            <li>Corporate Leadership Program</li>
                            <li>Technical Training</li>
                            <li>Language Training</li>
                       
                        </ul>
                     </div>
                </div>
                <div class="col-md-3">
                    <div class="col">
                       <h4>Contact us</h4>
                       <ul>
                            <li>Globoficent Management Consulting Pvt. Ltd. No. 74,<br/> Shankara Arcade, Vanivilas Road, Basavanagudi, Bengaluru - 560004</li>
                            <li>Phone: +91 988 602 0336 </li>
                            <li>Email: <a href="mailto:info@whilo.in" title="Email Us">info@whilo.in</a></li>
                            </ul>
                     </div>
                </div>
                
              

                
            </div>
            
            <hr>
            
            <div class="row">
                <div class="col-lg-9 copyright">
                    2016 © Whilo. All rights reserved.
                  
                </div>
                <div class="col-lg-3">
                     <div class="col-md-12">
                    <div class="col col-social-icons">
                      
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
               
                    </div>
                </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<style>
body{font-family:Tw Cen MT !important;}
ul li,p{    font-size: 16px;
    line-height: 21px;}
</style>
@endsection

@section('after-scripts-end')
@endsection
