<?php

namespace App\Repositories\Frontend\Resumes;
use App\Http\Controllers\Controller;


use DB;
/**
 * Class FrontendController
 * @package App\Http\Controllers
 */
class ResumesPermession extends Controller
{
	public static function insert($id)
	{
		
		$createdDate = date("d-m-Y h:i:s");
		$res = DB::insert('insert into jdocpermision(seekerId,companyId,status,createdDate) 
	   				values (?,?,?,?)',array($id,$_SESSION['WHILLO']['COMPAnyID'],1,$createdDate));
					
		$permissionid =  DB::getPdo()->lastInsertId();
		$res = DB::insert('insert into companypayments(companyId,permissionId,amount,status) 
	   				values (?,?,?,?)',array($_SESSION['WHILLO']['COMPAnyID'],$permissionid,4,0));			
		
		return response()->json(array(
					'success' => true,
					'errors' => "You got the full permission"
					));
		
		return $response;
	}
    
}