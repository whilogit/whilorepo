(function ($) {
	'use strict';

	$.sceditor.locale['en-US'] = {
		dateFormat: 'month/day/year'
	};
})(jQuery);
